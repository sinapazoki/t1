<?php $__env->startSection('title' , 'صفحه اصلی'); ?>

<?php $__env->startSection('content'); ?>

<!-- Component Code -->

<div class="relative h-screen w-full flex items-center justify-center bg-cover bg-center text-center px-5" style="background-image:url(https://images.pexels.com/photos/260689/pexels-photo-260689.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500);">
    <div class="absolute top-0 right-0 bottom-0 left-0 bg-gray-900 opacity-75"></div>
    
    <div class="z-50 flex flex-col justify-center text-white w-full h-screen">
      <img class="mx-auto h-28 w-auto" src="<?php echo e('/storage/admin-image/logo-white.png'); ?>" alt="Workflow">
      <h1 class="text-8xl"><b>بـــه زودی</b></h1>
    <p class="mt-5 ">با تی وان در کنارتان هستیم!</p>
    



    <div class="grid grid-flow-col gap-10 text-center auto-cols-max mx-auto sm:mt-10">
        <div class="flex flex-col">
            <span class="countdown text-8xl">
              <span id="sec" style="--value:52;"></span>
            </span>
            <span class="text-xl">ثانیه</span>
            
          </div>
          <div class="flex flex-col">
            <span class="countdown text-8xl">
              <span id="min" style="--value:24;"></span>
            </span>
            <span class="text-xl">دقیقه</span>
            
          </div> 
          <div class="flex flex-col">
            <span class="countdown text-8xl">
              <span id="hours" style="--value:10;"></span>
            </span>
            <span class="text-xl">ساعت</span>
          </div> 
        <div class="flex flex-col">
          <span class="countdown text-8xl">
            <span id="days" style="--value:15;"></span>
          </span>
          <span class="text-xl">روز</span>
          
        </div> 



      </div>

      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('emailnotifyform')->html();
} elseif ($_instance->childHasBeenRendered('MuG6zK3')) {
    $componentId = $_instance->getRenderedChildComponentId('MuG6zK3');
    $componentTag = $_instance->getRenderedChildComponentTagName('MuG6zK3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MuG6zK3');
} else {
    $response = \Livewire\Livewire::mount('emailnotifyform');
    $html = $response->html();
    $_instance->logRenderedChild('MuG6zK3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

      
      
    
  </div>
  

  <?php $__env->startSection('footer-scripts'); ?>

  <script>

    var countDownDate = new Date("Aug 22, 2022 23:59:25").getTime();

    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById('days').style.setProperty('--value', days);
        document.getElementById('hours').style.setProperty('--value', hours)
        document.getElementById('min').style.setProperty('--value', minutes)
        document.getElementById('sec').style.setProperty('--value', seconds)

    }, 1000)
</script>

    
  <?php $__env->stopSection(); ?>

  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.Customer.layouts.master-noheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\tivan\resources\views/site/Pages/welcome.blade.php ENDPATH**/ ?>