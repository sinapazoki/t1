<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <?php $__env->startSection('header-scripts'); ?>

        <?php echo $__env->yieldSection(); ?>
        <title>  <?php echo $__env->yieldContent('title'); ?></title>
        <?php echo \Livewire\Livewire::styles(); ?>


   </head>


        <body class="main font-iranyekan bg-[#f3f4f6] flex flex-col h-screen justify-between" >

          <?php echo \Livewire\Livewire::scripts(); ?>

          <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>




              <main class="my-auto">

                    <?php $__env->startSection('content'); ?>

                    <?php echo $__env->yieldSection(); ?>

              </main>






              

          <script>
            feather.replace()
          </script>
         


            <?php $__env->startSection('footer-scripts'); ?>

            <?php echo $__env->yieldSection(); ?>




            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'livewire-alert::components.scripts','data' => []]); ?>
<?php $component->withName('livewire-alert::scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        </body>


</html>
<?php /**PATH C:\wamp64\www\tivan\resources\views/site/Customer/layouts/master-noheader.blade.php ENDPATH**/ ?>